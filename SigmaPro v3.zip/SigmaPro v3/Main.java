// AprovaPay Mini — Java 25. Classes reunidas para facilitar a apresentação.
import java.io.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Scanner;
import java.util.Set;

// Main
public class Main {
public static void main(String[] args) throws java.io.IOException {
        Scanner scanner = new Scanner(System.in);
        ArquivoSessao arquivo = new ArquivoSessao(java.nio.file.Path.of(System.getProperty("sigmapro.dados", "dados/sessao.bin")));
        ContaBancaria conta = arquivo.carregar().orElse(null);
        Usuario cliente = conta == null ? new Usuario() : conta.getTitular();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        System.out.println("=========================================");
        System.out.println("      BEM-VINDO AO APROVAPAY MINI        ");
        System.out.println("=========================================");
        if (conta == null) {
        System.out.println("Vamos abrir a sua conta cliente.");

    while (true) {
        try {
            System.out.print("\nDigite seu Nome: ");
            cliente.setNome(scanner.nextLine());
            break;
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Erro: " + e.getMessage());
        }
    }
    while (true) {
        try {
            System.out.print("Digite seu CPF (000.000.000-00): ");
            cliente.setCpf(scanner.nextLine());
            break;
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Erro: " + e.getMessage());
        }
    }
    while (true) {
        try {
            System.out.print("Data de Nascimento (DD/MM/AAAA): ");
            String dataStr = scanner.nextLine();

            LocalDate dataNascimento = null;
            if (!dataStr.isBlank()) {
                try {
                    dataNascimento = LocalDate.parse(dataStr.trim(), formatter);
                } catch (DateTimeParseException e) {
                    throw new IllegalArgumentException("Formato de data inválido. Use DD/MM/AAAA.");
                }
            }

            cliente.setDataNascimento(dataNascimento);
            break;
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Erro: " + e.getMessage());
        }
    }

    while (true) {
        try {
            System.out.print("Crie uma Senha (mín. 6 caracteres): ");
            cliente.setSenha(scanner.nextLine());
            break;
        } catch (IllegalArgumentException e) {
            System.out.println("❌ Erro: " + e.getMessage());
        }
    }
    System.out.println("✅ Usuário criado com sucesso!");


        while (conta == null) {
            try {
                System.out.print("\nQual será o saldo inicial da sua conta? R$ ");
                String saldoStr = scanner.nextLine().replace(",", ".");
                System.out.print("\nDigite sua senha: ");
                String senha = scanner.nextLine();
                if(senha.equals(cliente.getSenha())){
                conta = new ContaBancaria(cliente, new BigDecimal(saldoStr));
                System.out.println("✅ Conta bancária criada!");}
                else{
                    System.out.println("Senha incorreta tente de novo");
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Erro: Digite um valor válido.");
            }
            catch (IllegalArgumentException e){
                System.out.println("❌ Erro: " + e.getMessage());
            }
        }

        } else {
            System.out.println("Sessão local de " + cliente.getNome() + " carregada");
            System.out.print("Digite sua senha: ");
            if (!scanner.nextLine().equals(cliente.getSenha())) { System.out.println("Senha incorreta."); return; }
        }
        arquivo.salvar(conta);

        // GERENTES PARA TESTAR AS APROVAÇÕES
        Usuario gerente1 = new Usuario("Gerente Ana", "111.222.333-44", LocalDate.of(1985, 5, 10), "senha123");
        Usuario gerente2 = new Usuario("Gerente Carlos", "555.666.777-88", LocalDate.of(1980, 8, 20), "senha123");
        Usuario gerenteBloqueado = new Usuario("Gerente Pedro BLOQUEADO", "999.888.777-66", LocalDate.of(1992, 2, 2), "senha123");
        gerenteBloqueado.setBloqueado(true);

        Usuario gerente4 = new Usuario("Gerente Diego", "222.333.444-55", LocalDate.of(1990, 1, 1), "senha123");
        List<Transacao> transacoesPendentes = new ArrayList<>(conta.getExtrato().stream().filter(t -> t.getStatus() != StatusTransacao.EFETIVADA).toList());

    // 4. MENU INTERATIVO
    int opcao = 0;
    while (opcao != 6) {
        System.out.println("\n=========================================");
        System.out.println("Olá, " + cliente.getNome() + " | Saldo: R$ " + conta.getSaldo());
        System.out.println("1. Depositar (Acima de 10 mil exige outra aprovação)");
        System.out.println("2. Solicitar Saque (Vai para Análise)");
        System.out.println("3. Solicitar Transferência (Vai para Análise)");
        System.out.println("4. Ver Extrato da Conta");
        System.out.println("5. Painel de Gerência (Aprovar/Rejeitar Transações)");
        System.out.println("6. Sair");
        System.out.print("Escolha uma opção: ");

        try {
            if (!scanner.hasNextLine()) break;
            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1:
                    System.out.print("Qual valor deseja depositar? R$ ");
                    BigDecimal valorDep = new BigDecimal(scanner.nextLine().replace(",", "."));
                    Transacao deposito = conta.depositar(valorDep);
                    if (deposito.getStatus() == StatusTransacao.PENDENTE) transacoesPendentes.add(deposito);
                    System.out.println("Depósito: " + deposito.getStatus());
                    break;

                case 2:
                    System.out.print("Qual valor deseja sacar? R$ ");
                    BigDecimal valorSaq = new BigDecimal(scanner.nextLine().replace(",", "."));
                    Transacao t = conta.solicitarSaque(valorSaq);

                    // Verifica se é até R$ 10.000,00 inclusive
                    if (valorSaq.compareTo(new BigDecimal("10000.00")) <= 0) {
                        System.out.print("Confirma o SAQUE no valor de R$ " + valorSaq + "? (S/N): ");
                        String confirmacao = scanner.nextLine().trim();

                        if (confirmacao.equalsIgnoreCase("S") || confirmacao.equalsIgnoreCase("SIM")) {
                            t.aprovar(cliente, "Confirmado pelo próprio usuário");
                            System.out.println("✅ Saque confirmado e efetivado!");
                        } else {
                            t.rejeitar(cliente, "Cancelado pelo usuário na confirmação");
                            transacoesPendentes.add(t);
                            System.out.println("❌ Saque cancelado.");
                        }
                    } else {
                        transacoesPendentes.add(t);
                        System.out.println("⏳ Valor acima de R$ 10.000,00. Saque enviado para o painel de aprovação da gerência!");
                    }
                    break;

                case 3:
                    Usuario usuarioDestino = new Usuario();

                    // 1. Lê e valida o Nome do destinatário
                    while (true) {
                        try {
                            System.out.print("Nome de quem vai receber a transferência: ");
                            usuarioDestino.setNome(scanner.nextLine());
                            break;
                        } catch (IllegalArgumentException e) {
                            System.out.println("❌ Erro: " + e.getMessage());
                        }
                    }

                    // 2. Lê e valida o CPF do destinatário
                    while (true) {
                        try {
                            System.out.print("CPF do destinatário (000.000.000-00): ");
                            usuarioDestino.setCpf(scanner.nextLine());
                            break;
                        } catch (IllegalArgumentException e) {
                            System.out.println("❌ Erro: " + e.getMessage());
                        }
                    }

                    ContaBancaria contaDestino = new ContaBancaria(usuarioDestino, BigDecimal.ZERO);

                    System.out.print("Qual valor deseja transferir? R$ ");
                    BigDecimal valorDigitado = new BigDecimal(scanner.nextLine().replace(",", "."));
                    BigDecimal valorTransf = aplicarAjusteTarifario(valorDigitado);

                    Transacao transf = conta.solicitarTransferencia(contaDestino, valorTransf);

                    // Verifica se é até R$ 10.000,00 inclusive
                    if (valorTransf.compareTo(new BigDecimal("10000.00")) <= 0) {
                        System.out.print("Confirma a TRANSFERÊNCIA de R$ " + valorTransf + " para " + usuarioDestino.getNome() + " (CPF: " + usuarioDestino.getCpf() + ")? (S/N): ");
                        String confirmacao = scanner.nextLine().trim();

                        if (confirmacao.equalsIgnoreCase("S") || confirmacao.equalsIgnoreCase("SIM")) {
                            transf.aprovar(cliente, "Confirmado pelo próprio usuário");
                            System.out.println("✅ Transferência para " + usuarioDestino.getNome() + " confirmada e efetivada!");
                        } else {
                            transf.rejeitar(cliente, "Cancelado pelo usuário na confirmação");
                            transacoesPendentes.add(transf);
                            System.out.println("❌ Transferência cancelada.");
                        }
                    } else {
                        transacoesPendentes.add(transf);
                        System.out.println("⏳ Valor acima de R$ 10.000,00. Transferência enviada para análise da gerência!");
                    }
                    break;

                case 4:
                    conta.imprimirExtrato();
                    break;

                case 5:
                    // PAINEL DE APROVAÇÃO
                    if (transacoesPendentes.isEmpty()) {
                        System.out.println("✅ Nenhuma transação pendente no momento.");
                        break;
                    }

                    System.out.println("\n--- TRANSAÇÕES AGUARDANDO ANÁLISE ---");
                    for (int i = 0; i < transacoesPendentes.size(); i++) {
                        Transacao pendente = transacoesPendentes.get(i);
                        String destinoStr = (pendente.getDestino() != null) ? " para " + pendente.getDestino().getTitular().getNome() : "";
                        System.out.println(i + " -> " + pendente.getTipo() + destinoStr + " de R$ " + pendente.getValor() + " | Status: " + pendente.getStatus());
                    }

                    System.out.print("Digite o número da transação para analisar: ");
                    int indice = Integer.parseInt(scanner.nextLine());
                    Transacao selecionada = transacoesPendentes.get(indice);

                    System.out.println("\nQuem está analisando?");
                    System.out.println("1. " + gerente1.getNome());
                    System.out.println("2. " + gerente2.getNome());
                    System.out.println("3. " + gerenteBloqueado.getNome());
                    System.out.println("4. " + gerente4.getNome());
                    System.out.print("Escolha o gerente: ");
                    int opGerente = Integer.parseInt(scanner.nextLine());

                    Usuario avaliador = switch (opGerente) { case 1 -> gerente1; case 2 -> gerente2; case 3 -> gerenteBloqueado; case 4 -> gerente4; default -> throw new IllegalArgumentException("Gerente inválido."); };

                    System.out.println("\nO que deseja fazer?");
                    System.out.println("1. Aprovar");
                    System.out.println("2. Rejeitar");
                    System.out.println("3. Solicitar Nova Análise (Para transações já rejeitadas)");
                    System.out.print("Ação: ");
                    int acao = Integer.parseInt(scanner.nextLine());

                    System.out.print("Digite uma justificativa para a decisão: ");
                    String justificativa = scanner.nextLine();

                    try {
                        if (acao == 1) {
                            selecionada.aprovar(avaliador, justificativa);
                            System.out.println("✅ Decisão de aprovação registrada.");
                            if (selecionada.getStatus() == StatusTransacao.EFETIVADA) {
                                System.out.println("APROVAÇÕES SUFICIENTES! O saldo foi atualizado.");
                                transacoesPendentes.remove(selecionada);
                            } else {
                                System.out.println("⚠️ Ainda falta aprovação de outro gerente.");
                            }
                        } else if (acao == 2) {
                            selecionada.rejeitar(avaliador, justificativa);
                            System.out.println("❌ Transação Rejeitada.");
                        } else if (acao == 3) {
                            selecionada.solicitarNovaAnalise(avaliador, justificativa);
                            System.out.println("🔄 Transação retornou para Pendente (Histórico mantido).");
                        }
                    } catch (Exception e) {
                        System.out.println("⚠️ ALERTA DA REGRA DE NEGÓCIO: " + e.getMessage());
                    }
                    break;

                case 6:
                    System.out.println("Saindo do AprovaPay Mini. Até logo!");
                    break;

                default:
                    System.out.println("❌ Opção inválida.");
            }

        } catch (NumberFormatException e) {
            System.out.println("❌ Erro: Digite apenas números nas opções ou valores.");
        } catch (IndexOutOfBoundsException e) {
            System.out.println("❌ Erro: Transação não encontrada.");
        } catch (Exception e) {
            System.out.println("❌ Erro na operação: " + e.getMessage());
        }
        arquivo.salvar(conta);
    }
        arquivo.salvar(conta);
        scanner.close();
    }
    private static BigDecimal aplicarAjusteTarifario(BigDecimal valor) {
        return valor; // Não há tarifa prevista nos requisitos do cenário.
    }
}

// Usuario
class Usuario implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private String nome;
    private String cpf;
    private LocalDate dataNascimento;
    private String senha;
    private boolean bloqueado;

    public Usuario(String nome, String cpf, LocalDate dataNascimento, String senha) {
        setNome(nome);
        setCpf(cpf);
        setDataNascimento(dataNascimento);
        setSenha(senha);
        this.bloqueado = false;
    }
    public Usuario(){
        this.bloqueado = false;
    }
    public boolean isBloqueado(){return bloqueado;}
    public void setBloqueado(boolean bloqueado)
    {this.bloqueado = bloqueado;}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException(
                    "Nome não pode ser vazio ou conter apenas espaços."
            );
        }
        this.nome = nome.trim();
        if (!nome.matches("^[a-zA-ZÀ-ÿ ]+$")) {
            throw new IllegalArgumentException(
                    "Nome inválido. Utilize apenas letras"
            );
        }
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (cpf == null || cpf.isBlank()) {
            throw new IllegalArgumentException(
                    "CPF não pode ser vazio ou conter apenas espaços."
            );
        }
        String cpfFormatado = cpf.trim();
        String regexFormatacao = "^\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}$";
        if(!cpfFormatado.matches(regexFormatacao)) {
            throw new IllegalArgumentException(
                    "CPF inválido. Digite somente números. e no formato esperado: 000.000.000-00"
            );
        }
        this.cpf = cpfFormatado;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        if (dataNascimento == null) {
            throw new IllegalArgumentException(
                    "Data de nascimento é obrigatória."
            );
        } if (dataNascimento.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException(
                    "Data de nascimento não pode ser futura."
            );
        }
        this.dataNascimento = dataNascimento;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        if (senha == null || senha.isBlank()) {
            throw new IllegalArgumentException(
                    "Senha não pode ser vazia ou conter apenas espaços."
            );
        }
        if (senha.length() < 6) {
            throw new IllegalArgumentException(
                    "Senha deve ter pelo menos 6 caracteres."
            );
        }
        this.senha = senha;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return Objects.equals(cpf, usuario.cpf);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cpf);
    }
}

// ContaBancaria
class ContaBancaria implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    private Usuario titular;
    private BigDecimal saldo;
    private List<Transacao> extrato;

    public ContaBancaria(Usuario titular, BigDecimal saldoInicial) {
        if (saldoInicial != null && saldoInicial.compareTo(BigDecimal.ZERO) < 0){
            throw new IllegalArgumentException("Saldo inicial não pode ser negativo.");
        }
        this.titular = titular;
        this.saldo = saldoInicial != null ? saldoInicial : BigDecimal.ZERO;
        this.extrato = new ArrayList<>();
    }

    public Transacao depositar(BigDecimal valor) {
        Transacao t = new Transacao("DEPÓSITO", valor, this, null);
        t.aprovar(titular, "Auto-aprovação de depósito"); // Efetiva imediatamente
        extrato.add(t);
        return t;
    }


    public Transacao solicitarSaque(BigDecimal valor) {
        if (this.saldo.compareTo(valor) < 0) {
            throw new IllegalArgumentException("Saldo insuficiente para solicitar o saque");
        }
        Transacao t = new Transacao("SAQUE", valor, this, null);
        extrato.add(t);
        return t;
    }


    public Transacao solicitarTransferencia(ContaBancaria destino, BigDecimal valor) {
        if (destino == null) {
            throw new IllegalArgumentException("A conta de destino não pode ser nula.");
        }
        if (this.saldo.compareTo(valor) < 0) {
            throw new IllegalArgumentException("Saldo insuficiente para a transferência.");
        }
        Transacao t = new Transacao("TRANSFERÊNCIA", valor, this, destino);
        extrato.add(t);
        destino.adicionarAoExtrato(t);
        return t;
    }

    // Métodos internos chamados pela classe Transacao quando a mesma é efetivada
    protected void executarDebito(BigDecimal valor) {
        this.saldo = this.saldo.subtract(valor);
    }

    protected void executarCredito(BigDecimal valor) {
        this.saldo = this.saldo.add(valor);
    }

    protected void adicionarAoExtrato(Transacao t) {
        this.extrato.add(t);
    }

    public void imprimirExtrato() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        System.out.println("\n==============================================================");
        System.out.println("EXTRATO DETALHADO - Titular: " + titular.getNome() + " (CPF: " + titular.getCpf() + ")");
        System.out.println("==============================================================");

        if (extrato.isEmpty()) {
            System.out.println("Nenhuma transação realizada.");
        } else {
            for (Transacao t : extrato) {
                String dataStr = (t.getDataCriacao() != null) ? t.getDataCriacao().format(fmt) : "Data N/D";
                System.out.println("\n• [" + t.getStatus() + "] " + t.getTipo() + " | Valor: R$ " + t.getValor() + " | Solicitada em: " + dataStr);

                if (t.getDestino() != null) {
                    Usuario dest = t.getDestino().getTitular();
                    System.out.println("  Destinatário: " + dest.getNome() + " (CPF: " + dest.getCpf() + ")");
                }

                System.out.println("  Fluxo de Decisões:");
                if (t.getHistorico() == null || t.getHistorico().isEmpty()) {
                    System.out.println("    - Aguardando análise.");
                } else {
                    for (RegistroDecisao registro : t.getHistorico()) {
                        System.out.println("    - " + registro.toString());
                    }
                }
                System.out.println("--------------------------------------------------------------");
            }
        }
        System.out.println("SALDO ATUAL: R$ " + this.saldo);
        System.out.println("==============================================================\n");
    }

    public List<Transacao> getExtrato() { return List.copyOf(extrato); }
    public Usuario getTitular() { return titular; }
    public BigDecimal getSaldo() { return saldo; }
}

// Transacao
class Transacao implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
        private String tipo; // "SAQUE", "DEPÓSITO", "TRANSFERÊNCIA"
        private BigDecimal valor;
        private ContaBancaria origem;
        private ContaBancaria destino;
        private StatusTransacao status;
        private LocalDateTime dataCriacao;

        private Set<Usuario> usuariosQueAprovaram;
        private List<RegistroDecisao> historico;

        public Transacao(String tipo, BigDecimal valor, ContaBancaria origem, ContaBancaria destino) {
            if (valor == null || valor.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("O valor da transação deve ser positivo.");
            }
            this.tipo = tipo;
            this.valor = valor;
            this.origem = origem;
            this.destino = destino;
            this.status = StatusTransacao.PENDENTE;
            this.dataCriacao = LocalDateTime.now();
            this.usuariosQueAprovaram = new HashSet<>();
            this.historico = new ArrayList<>();
        }

        public void aprovar(Usuario avaliador, String justificativa) {
            if (status == StatusTransacao.EFETIVADA) {
                throw new IllegalStateException("Transação já foi efetivada.");
            }
            if (status == StatusTransacao.REJEITADA) {
                throw new IllegalStateException("Impedido liberação de transação rejeitada . Solicite nova análise.");
            }
            if (avaliador.isBloqueado()) {
                throw new IllegalStateException("Impedido aprovação por usuário bloqueado .");
            }
            boolean jaAprovou = historico.stream().anyMatch(r -> r.isAprovada() && r.getCpfUsuario().equals(avaliador.getCpf()));
            if (jaAprovou) { // RF03: proteção contra duplicidade
                throw new IllegalStateException("O mesmo usuário não pode aprovar duas vezes.");
            }

            int necessarias = valor.compareTo(new BigDecimal("10000.00")) > 0 ? 2 : 1;
            if (usuariosQueAprovaram.size() + 1 >= necessarias && !tipo.equals("DEPÓSITO")
                    && origem.getSaldo().compareTo(valor) < 0)
                throw new IllegalStateException("Saldo insuficiente na efetivação.");
            usuariosQueAprovaram.add(avaliador);
            historico.add(new RegistroDecisao(avaliador, true, justificativa)); // RF06

            verificarEfetivacao();
        }

        public void rejeitar(Usuario avaliador, String justificativa) {
            if (status == StatusTransacao.EFETIVADA) {
                throw new IllegalStateException("Transação já efetivada não pode ser rejeitada.");
            }
            this.status = StatusTransacao.REJEITADA;
            historico.add(new RegistroDecisao(avaliador, false, justificativa)); // RF06
        }

        public void solicitarNovaAnalise(String justificativa) {
            solicitarNovaAnalise(origem.getTitular(), justificativa);
        }

        public void solicitarNovaAnalise(Usuario solicitante, String justificativa) {
            if (solicitante == null) throw new IllegalArgumentException("Solicitante obrigatório.");
            if (status != StatusTransacao.REJEITADA) {
                throw new IllegalStateException("Apenas transações rejeitadas podem solicitar nova análise.");
            }
            justificativa = validarJustificativa(justificativa);
            this.status = StatusTransacao.PENDENTE;
            this.usuariosQueAprovaram.clear();
            this.historico.add(new RegistroDecisao(solicitante, RegistroDecisao.Tipo.NOVA_ANALISE, justificativa));
        }

    private static String validarJustificativa(String justificativa) {
        if (justificativa == null || justificativa.isBlank()) throw new IllegalArgumentException("Justificativa obrigatória.");
        return justificativa.strip();
    }

    private void verificarEfetivacao() {

        int aprovacoesNecessarias = 1;

        if (valor.compareTo(new BigDecimal("10000.00")) > 0) {
            aprovacoesNecessarias = 2;
        }

        if (usuariosQueAprovaram.size() >= aprovacoesNecessarias) {
            this.status = StatusTransacao.EFETIVADA;

            if (tipo.equals("SAQUE") || tipo.equals("TRANSFERÊNCIA")) {
                origem.executarDebito(valor);
            }
            if (tipo.equals("DEPÓSITO")) {
                origem.executarCredito(valor);
            }
            if (tipo.equals("TRANSFERÊNCIA") && destino != null) {
                destino.executarCredito(valor);
            }
        }
    }
        public StatusTransacao getStatus() { return status; }
        public String getTipo() { return tipo; }
        public BigDecimal getValor() { return valor; }
        public LocalDateTime getDataCriacao(){ return dataCriacao; }
        public List<RegistroDecisao> getHistorico() { return List.copyOf(historico); }
        public ContaBancaria getDestino() { return destino; }
    }

// RegistroDecisao
class RegistroDecisao implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    public enum Tipo { APROVACAO, REJEICAO, NOVA_ANALISE }
    private final Tipo tipo;
    private final String nomeUsuario;
    private final String cpfUsuario;
    private Usuario avaliador;
    private boolean aprovada;
    private String justificativa;
    private LocalDateTime dataHora;

    public RegistroDecisao(Usuario avaliador, boolean aprovada, String justificativa) {
        this(avaliador, aprovada ? Tipo.APROVACAO : Tipo.REJEICAO, justificativa);
    }

    public RegistroDecisao(Usuario avaliador, Tipo tipo, String justificativa) {
        this.tipo = tipo;
        this.nomeUsuario = avaliador.getNome();
        this.cpfUsuario = avaliador.getCpf();
        this.avaliador = avaliador;
        this.aprovada = tipo == Tipo.APROVACAO;
        this.justificativa = (justificativa == null || justificativa.isBlank()) ? "Sem justificativa" : justificativa;
        this.dataHora = LocalDateTime.now();
    }

    public Tipo getTipo() { return tipo; }
    public String getCpfUsuario() { return cpfUsuario; }
    public Usuario getAvaliador() { return avaliador; }
    public boolean isAprovada() { return aprovada; }
    public String getJustificativa() { return justificativa; }
    public LocalDateTime getDataHora() { return dataHora; }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String acao = tipo == Tipo.NOVA_ANALISE ? "NOVA ANALISE" : aprovada ? "APROVADA" : "REJEITADA";
        return String.format("[%s] %s por %s (CPF: %s) | Justificativa: \"%s\"",
                dataHora.format(fmt),
                acao,
                nomeUsuario,
                cpfUsuario,
                justificativa);
    }
}

// StatusTransacao
enum StatusTransacao {
    PENDENTE,
    REJEITADA,
    EFETIVADA,

}

// ArquivoSessao
/** Persistência local de dados fictícios da demonstração. */
final class ArquivoSessao {
    private final Path arquivo;
    public ArquivoSessao(Path arquivo) { this.arquivo = arquivo.toAbsolutePath(); }
    public Optional<ContaBancaria> carregar() throws IOException {
        if (!Files.exists(arquivo)) return Optional.empty();
        try (var in = new ObjectInputStream(Files.newInputStream(arquivo))) {
            in.setObjectInputFilter(ObjectInputFilter.Config.createFilter(
                "maxdepth=30;maxrefs=10000;maxbytes=2000000;java.base/*;Usuario;ContaBancaria;Transacao;RegistroDecisao;RegistroDecisao$Tipo;StatusTransacao;!*"));
            Object valor = in.readObject();
            if (!(valor instanceof ContaBancaria conta)) throw new IOException("Arquivo de sessão incompatível.");
            return Optional.of(conta);
        } catch (ClassNotFoundException | RuntimeException e) { throw new IOException("Não foi possível carregar a sessão.", e); }
    }
    public void salvar(ContaBancaria conta) throws IOException {
        Files.createDirectories(arquivo.getParent());
        Path temporario = Files.createTempFile(arquivo.getParent(), "sessao-", ".tmp");
        try {
            try (var out = new ObjectOutputStream(Files.newOutputStream(temporario))) { out.writeObject(conta); }
            try { Files.move(temporario, arquivo, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temporario, arquivo, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temporario); }
    }
}
